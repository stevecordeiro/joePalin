
	//list all of our hotspots here in an Array
	//index 0 should have the same value as the final index
	var playslipScannerArray = new Array();
	
	playslipScannerArray[0] = "M 371 156 l 1 88 l 81 -3 l -5 -90 z";
	playslipScannerArray[1] = "M 413 158 l 5 70 l 59 -2 l -9 -70 z";
	playslipScannerArray[2] = "M 424 166 l 16 60 l 59 0 l -15 -68 z";
	playslipScannerArray[3] = "M 432 163 l 24 66 l 41 -4 l 0 -62 z";
	playslipScannerArray[4] = "M 431 164 l 29 63 l 34 -5 l -21 -61 z";
	playslipScannerArray[5] = "M 421 167 l 29 60 l 22 -7 l -29 -58 z";
	playslipScannerArray[6] = "M 398 169 l 26 54 l 19 -2 l -27 -53 z";
	playslipScannerArray[7] = "";
	playslipScannerArray[8] = "";
	playslipScannerArray[9] = "M 209 175 l -3 36 l 17 -1 l 8 -37 z";
	playslipScannerArray[10] = "M 152 170 l -3 53 l 43 -1 l 7 -55 z";
	playslipScannerArray[11] = "M 120 169 l 9 61 l 55 -5 l -6 -62 z";
	playslipScannerArray[12] = "M 95 166 l 0 68 l 54 -1 l -2 -75 z";
	playslipScannerArray[13] = "M 71 161 l -6 68 l 68 -2 l -2 -66 z";
	playslipScannerArray[14] = "M 55 161 l -9 69 l 84 2 l 10 -69 z";
	playslipScannerArray[15] = "M 46 160 l -4 70 l 107 -3 l 2 -70 z";
	playslipScannerArray[16] = "M 60 161 l -11 70 l 129 -3 l 1 -69 z";
	playslipScannerArray[17] = "M 88 158 l -9 68 l 139 -5 l -4 -63 z";
	playslipScannerArray[18] = "M 130 159 l -10 67 l 141 -2 l -14 -65 z";	
	playslipScannerArray[19] = "M 173 158 l -13 64 l 136 -2 l -9 -56 z";
	playslipScannerArray[20] = "M 234 159 l -8 65 l 120 -2 l -6 -62 z";
	playslipScannerArray[21] = "M 295 156 l -12 69 l 112 3 l -16 -68 z";
	playslipScannerArray[22] = "M 343 156 l -5 70 l 86 0 l -17 -68 z";
	playslipScannerArray[23] = "M 393 158 l -8 69 l 69 2 l -12 -75 z";

	
	
	var i = 0;