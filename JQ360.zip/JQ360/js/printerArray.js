
	//list all of our hotspots here in an Array
	//index 0 should have the same value as the final index
	var printerArray = new Array();
	
	printerArray[0] = "M 207 40 l 3 28 l 52 -2 l -5 -25 z";
	printerArray[1] = "M 160 41 l 1 31 l 87 -7 l -23 -30 z";
	printerArray[2] = "M 120 42 l -11 103 l 44 2 l 54 -98 z";
	printerArray[3] = "M 79 43 l -9 116 l 97 -8 l 28 -101 z";
	printerArray[4] = "M 47 44 l 4 127 l 136 1 l -16 -130 z";
	printerArray[5] = "M 22 41 l -6 149 l 179 -19 l -12 -124 z";
	printerArray[6] = "M 3 45 l -1 156 l 194 -6 l -29 -149 z";
	printerArray[7] = "M 2 41 l -1 168 l 214 -18 l -29 -141 z";
	printerArray[8] = "M 2 45 l 1 181 l 235 -30 l -42 -159 z";
	printerArray[9] = "M 14 43 l -11 169 l 258 -7 l -40 -162 z";
	printerArray[10] = "M 42 48 l 16 171 l 218 -1 l -24 -169 z";
	printerArray[11] = "M 111 52 l -6 172 l 150 4 l 12 -178 z";
	printerArray[12] = "M 183 49 l -4 163 l 136 -1 l -14 -163 z";
	printerArray[13] = "M 204 47 l -13 148 l 178 41 l -3 -194 z";
	printerArray[14] = "M 220 50 l -9 146 l 213 29 l 2 -180 z";
	printerArray[15] = "M 246 47 l -13 144 l 210 26 l 30 -172 z";
	printerArray[16] = "M 268 43 l -22 145 l 206 10 l 36 -156 z";
	printerArray[17] = "M 283 41 l -21 146 l 211 12 l 16 -156 z";
	printerArray[18] = "M 286 35 l -16 141 l 209 5 l 3 -143 z";
	printerArray[19] = "M 274 38 l 16 129 l 153 -1 l 21 -127 z";
	printerArray[20] = "M 281 38 l 34 133 l 102 -5 l 16 -137 z";
	printerArray[21] = "M 317 37 l -52 30 l 121 78 l -3 -112 z";
	printerArray[22] = "M 260 37 l -4 31 l 93 29 l -4 -67 z";
	printerArray[23] = "M 238 34 l -6 30 l 71 8 l 1 -38 z";
	printerArray[24] = "M 207 40 l 3 28 l 52 -2 l -5 -25 z";
	
	
	var i = 0;