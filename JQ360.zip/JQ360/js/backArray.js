


	//list all of our hotspots here in an Array
	//index 0 should have the same value as the final index
	var backArray = new Array();
	
	backArray[0] = "M 280 177 l -1 40 l 44 2 l -1 -40 z";
	backArray[1] = "M 280 177 l -1 40 l 44 2 l -1 -40 z";
	backArray[2] = "M 280 177 l -1 40 l 44 2 l -1 -40 z";
	backArray[3] = "M 280 177 l -1 40 l 44 2 l -1 -40 z";
	backArray[4] = "M 280 177 l -1 40 l 44 2 l -1 -40 z";
	backArray[5] = "M 280 177 l -1 40 l 44 2 l -1 -40 z";
	backArray[6] = "M 280 177 l -1 40 l 44 2 l -1 -40 z";
	backArray[7] = "M 280 177 l -1 40 l 44 2 l -1 -40 z";
	backArray[8] = "M 280 177 l -1 40 l 44 2 l -1 -40 z";
	backArray[9] = "M 280 177 l -1 40 l 44 2 l -1 -40 z";
	backArray[10] = "M 280 177 l -1 40 l 44 2 l -1 -40 z";
	backArray[11] = "M 280 177 l -1 40 l 44 2 l -1 -40 z";
	backArray[12] = "M 280 177 l -1 40 l 44 2 l -1 -40 z";
	backArray[13] = "M 280 177 l -1 40 l 44 2 l -1 -40 z";
	backArray[14] = "M 280 177 l -1 40 l 44 2 l -1 -40 z";
	backArray[15] = "M 280 177 l -1 40 l 44 2 l -1 -40 z";
	backArray[16] = "M 280 177 l -1 40 l 44 2 l -1 -40 z";
	backArray[17] = "M 280 177 l -1 40 l 44 2 l -1 -40 z";
	backArray[18] = "M 280 177 l -1 40 l 44 2 l -1 -40 z";
	backArray[19] = "M 280 177 l -1 40 l 44 2 l -1 -40 z";	
	backArray[20] = "M 280 177 l -1 40 l 44 2 l -1 -40 z";
	backArray[21] = "M 280 177 l -1 40 l 44 2 l -1 -40 z";
	backArray[22] = "M 280 177 l -1 40 l 44 2 l -1 -40 z";
	backArray[23] = "M 280 177 l -1 40 l 44 2 l -1 -40 z";

	
	var i = 0;