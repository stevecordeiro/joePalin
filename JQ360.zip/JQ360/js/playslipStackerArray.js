	//list all of our hotspots here in an Array
	//index 0 should have the same value as the final index
	var playslipStackerArray = new Array();
	
	playslipStackerArray[0] = "M 149 267 l 4 90 l 195 1 l -2 -90 z";
	playslipStackerArray[1] = "M 182 268 l 6 94 l 195 -1 l -2 -99 z";
	playslipStackerArray[2] = "M 227 283 l -6 70 l 200 8 l -7 -80 z";
	playslipStackerArray[3] = "M 264 285 l -5 69 l 183 8 l -2 -85 z";
	playslipStackerArray[4] = "M 293 285 l -5 74 l 164 2 l 8 -86 z";
	playslipStackerArray[5] = "M 327 287 l -5 74 l 128 -2 l 9 -74 z";
	playslipStackerArray[6] = "M 354 285 l -5 72 l 101 3 l 6 -79 z";
	playslipStackerArray[7] = "M 372 288 l -3 64 l 92 3 l 5 -70 z";
	playslipStackerArray[8] = "M 392 290 l -7 70 l 83 -9 l -2 -60 z";
	playslipStackerArray[9] = "M 400 287 l -10 59 l 64 -5 l 11 -48 z";
	playslipStackerArray[10] = "M 386 291 l -4 49 l 26 -5 l 6 -41 z";
	playslipStackerArray[11] = "";
	playslipStackerArray[12] = "";
	playslipStackerArray[13] = "M 148 296 l 4 39 l 22 2 l -8 -43 z";
	playslipStackerArray[14] = "M 116 292 l 5 52 l 44 0 l -4 -54 z";
	playslipStackerArray[15] = "M 92 298 l 11 46 l 66 0 l -19 -58 z";
	playslipStackerArray[16] = "M 83 300 l 11 50 l 86 0 l -23 -68 z";
	playslipStackerArray[17] = "M 79 293 l 18 63 l 100 -1 l -34 -68 z";
	playslipStackerArray[18] = "M 88 297 l 21 61 l 100 -6 l -31 -70 z";	
	playslipStackerArray[19] = "M 77 298 l 21 57 l 134 5 l -38 -76 z";
	playslipStackerArray[20] = "M 76 285 l 14 68 l 166 4 l -11 -69 z";
	playslipStackerArray[21] = "M 83 287 l 15 71 l 190 2 l -8 -69 z";
	playslipStackerArray[22] = "M 111 288 l 4 71 l 201 3 l -3 -73 z";
	playslipStackerArray[23] = "M 154 285 l 1 76 l 192 0 l -3 -71 z";

	
	
	var i = 0;