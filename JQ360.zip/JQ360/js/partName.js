	//list all of our hardware parts that we want identified, here in an Array

	var partName = new Array();
	
	partName[0] = touchscreenArray;
	partName[1] = powerButtonArray;
	partName[2] = playslipReaderArray;
	partName[3] = playslipStackerArray;
	partName[4] = playslipScannerArray;
	partName[5] = connectionsArray;
	partName[6] = backArray;
	
	var i = 0;