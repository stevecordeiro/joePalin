	//list all of our hotspots here in an Array
	//index 0 should have the same value as the final index
	var playslipReaderArray = new Array();
	
	playslipReaderArray[0] = "";
	playslipReaderArray[1] = "";
	playslipReaderArray[2] = "";
	playslipReaderArray[3] = "M 208 95 l -1 30 l 16 -19 l -3 -16 z";
	playslipReaderArray[4] = "M 225 94 l 2 40 l 33 -28 l -4 -23 z";
	playslipReaderArray[5] = "M 249 88 l 3 55 l 42 -37 l -4 -22 z";
	playslipReaderArray[6] = "M 269 85 l 7 66 l 40 -38 l -22 -31 z";
	playslipReaderArray[7] = "M 273 90 l 8 69 l 35 -12 l 30 -53 z";
	playslipReaderArray[8] = "M 253 90 l 14 70 l 64 -2 l 23 -71 z";
	playslipReaderArray[9] = "M 232 91 l 13 64 l 111 2 l 13 -75 z";
	playslipReaderArray[10] = "M 209 96 l 5 71 l 158 -9 l -2 -68 z";
	playslipReaderArray[11] = "M 199 94 l 2 62 l 170 1 l -4 -68 z";
	playslipReaderArray[12] = "M 186 88 l 10 72 l 167 -2 l -8 -67 z";
	playslipReaderArray[13] = "M 184 85 l 9 74 l 157 7 l -6 -76 z";
	playslipReaderArray[14] = "M 177 82 l 19 70 l 138 6 l 1 -72 z";
	playslipReaderArray[15] = "M 188 82 l 21 77 l 101 -4 l 11 -69 z";
	playslipReaderArray[16] = "M 198 80 l 27 77 l 64 2 l 6 -69 z";
	playslipReaderArray[17] = "M 214 87 l 31 67 l 25 -3 l 1 -66 z";
	playslipReaderArray[18] = "M 225 90 l 38 54 l 19 -50 l -22 -21 z";
	playslipReaderArray[19] = "M 248 85 l 32 52 l 13 -45 l -24 -16 z";	
	playslipReaderArray[20] = "M 283 88 l 26 46 l 11 -31 l -21 -25 z";
	playslipReaderArray[21] = "";
	playslipReaderArray[22] = "";
	playslipReaderArray[23] = "";


	
	
	var i = 0;