
	//list all of our graphics here in an Array
	var terminalPics = new Array();
	terminalPics[0] = "assets/1.jpg";
	terminalPics[1] = "assets/terminal02.jpg";
	terminalPics[2] = "assets/terminal03.jpg";
	terminalPics[3] = "assets/terminal04.jpg";
	terminalPics[4] = "assets/terminal05.jpg";
	terminalPics[5] = "assets/terminal06.jpg";
	terminalPics[6] = "assets/terminal07.jpg";
	terminalPics[7] = "assets/terminal08.jpg";
	terminalPics[8] = "assets/terminal09.jpg";
	terminalPics[9] = "assets/terminal10.jpg";
	terminalPics[10] = "assets/terminal12.jpg";
	terminalPics[11] = "assets/terminal13.jpg";
	terminalPics[12] = "assets/terminal14.jpg";
	terminalPics[13] = "assets/terminal15.jpg";
	terminalPics[14] = "assets/terminal16.jpg";
	terminalPics[15] = "assets/terminal17.jpg";
	terminalPics[16] = "assets/terminal18.jpg";
	terminalPics[17] = "assets/terminal19.jpg";	
	terminalPics[18] = "assets/terminal20.jpg";
	terminalPics[19] = "assets/terminal21.jpg";
	terminalPics[20] = "assets/terminal22.jpg";
	terminalPics[21] = "assets/terminal23.jpg";
	terminalPics[22] = "assets/terminal24.jpg";
	terminalPics[23] = "assets/1.jpg";
	
	var i = 0;
	
	
	
