	//list all of our hotspots here in an Array
	//index 0 should have the same value as the final index
	var touchscreenArray = new Array();
	
	touchscreenArray[0] = "M 171 112 l -12 108 l 180 0 l 3 -112 z";
	touchscreenArray[1] = "M 190 108 l 3 112 l 181 -2 l -13 -112 z";
	touchscreenArray[2] = "M 225 112 l 28 109 l 159 -1 l -33 -111 z";
	touchscreenArray[3] = "M 259 108 l 42 113 l 131 -3 l -43 -107 z";
	touchscreenArray[4] = "M 294 109 l 52 110 l 93 0 l -50 -103 z";
	touchscreenArray[5] = "M 329 110 l 62 113 l 48 -3 l -57 -104 z";
	touchscreenArray[6] = "none";
	touchscreenArray[7] = "none";
	touchscreenArray[8] = "none";
	touchscreenArray[9] = "none";
	touchscreenArray[10] = "none";
	touchscreenArray[11] = "none";
	touchscreenArray[12] = "none";
	touchscreenArray[13] = "none";
	touchscreenArray[14] = "none";
	touchscreenArray[15] = "none";
	touchscreenArray[16] = "none";
	touchscreenArray[17] = "none";
	touchscreenArray[18] = "none";	
	touchscreenArray[19] = "M 165 119 l -60 102 l 42 -1 l 63 -115 z";
	touchscreenArray[20] = "M 166 116 l -59 103 l 47 3 l 60 -116 z";
	touchscreenArray[20] = "M 155 117 l -54 105 l 94 -1 l 55 -115 z";
	touchscreenArray[21] = "M 152 114 l -49 106 l 136 -1 l 39 -112 z";
	touchscreenArray[22] = "M 155 115 l -30 105 l 164 2 l 24 -116 z";
	touchscreenArray[23] = "M 173 111 l -12 110 l 179 -2 l 3 -112 z";

	
	var i = 0;