


	//list all of our hotspots here in an Array
	//index 0 should have the same value as the final index
	var connectionsArray = new Array();
	
	connectionsArray[0] = "";
	connectionsArray[1] = "";
	connectionsArray[2] = "";
	connectionsArray[3] = "";
	connectionsArray[4] = "";
	connectionsArray[5] = "";
	connectionsArray[6] = "";
	connectionsArray[7] = "";
	connectionsArray[8] = "";
	connectionsArray[9] = "M 142 300 l -2 39 l 92 11 l -5 -33 z";
	connectionsArray[10] = "M 153 308 l 1 37 l 157 8 l -2 -45 z";
	connectionsArray[11] = "M 181 309 l -2 43 l 175 5 l -3 -44 z";
	connectionsArray[12] = "M 213 311 l -1 44 l 174 -4 l 3 -40 z";
	connectionsArray[13] = "M 251 308 l -1 43 l 156 -1 l 2 -43 z";
	connectionsArray[14] = "M 295 307 l -10 43 l 133 -3 l 3 -42 z";
	connectionsArray[15] = "M 331 312 l -7 39 l 94 -8 l 2 -43 z";
	connectionsArray[16] = "";
	connectionsArray[17] = "";
	connectionsArray[18] = "";
	connectionsArray[19] = "";
	connectionsArray[20] = "";
	connectionsArray[21] = "";
	connectionsArray[22] = "";
	connectionsArray[23] = "";

	
	
	var i = 0;