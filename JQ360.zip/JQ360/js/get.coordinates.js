//Developed by Steve Cordeiro 2013//
//GTECH Corporation//

//This code records the x,y coordinates of the canvas container div and displays them on screen
//It also saves them as variables later to be used in an array

function getCoordinates(){
				$('#canvas_container').bind('click', function (e) {
					var $div 	= $(e.target),
						offset  = $div.offset(),
						x 		= e.clientX - offset.left,
						y 		= e.clientY - offset.top;	    
					//limit is 4
					if (clicks.length < limit){
						addCoordinates(x,y);
					}
				});
};


    
function addCoordinates (x,y){
    var	paper 	= new Raphael(document.getElementById('canvas_container'), 500, 500);
	var c = paper.circle(x,y,5);
	c.attr({fill:'#76EE00'});
	
	clicks.push( x + "," + y);
    
    updatedClicks.push("Coordinates" + ":" + clicks[clicks.length -1] + "<br />");

    $('.log').html(updatedClicks);
};

function clearCoordinates (x,y){

    $('.log').html('');
	clicks = [];
	updatedClicks = [];


};