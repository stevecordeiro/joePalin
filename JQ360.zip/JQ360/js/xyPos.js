var mie = (navigator.appName == "Microsoft Internet Explorer") ? true : false;

if (!mie) {
     document.captureEvents(Event.MOUSEMOVE);
     document.captureEvents(Event.MOUSEDOWN);
}

//document.onmousemove = function (e) {mousePos(e);};
//document.onmousedown = function (e) {mouseClicked();};

//var mouseClick;
//var keyClicked;

var mouseX = 0;
var mouseY = 0;

function mousePos (e) {
    if (!mie) {
		//mouseX = e.srcElement.style.left;
		//mouseY = e.srcElement.style.top;
        mouseX = e.pageX; 
        mouseY = e.pageY;
		//alert(e);
    }
    else {
		//mouseX = e.srcElement.style.left;
		//mouseY = e.srcElement.style.top;
        mouseX = event.clientX + document.canvas_container.scrollLeft;
        mouseY = event.clientY + document.canvas_container.scrollTop;
		//alert(e);
    }

    //document.show.mouseXField.value = mouseX;
    //document.show.mouseYField.value = mouseY;

    return true;
}
