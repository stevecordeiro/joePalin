	//list all of our hotspots here in an Array
	//index 0 should have the same value as the final index
	var powerButtonArray = new Array();
	
	powerButtonArray[0] = "M 347 105 l 1 18 l 13 1 l 1 -18 z";
	powerButtonArray[1] = "M 367 107 l 2 17 l 16 1 l -2 -18 z";
	powerButtonArray[2] = "M 381 108 l 9 19 l 16 -2 l -6 -16 z";
	powerButtonArray[3] = "M 387 110 l 10 18 l 16 0 l -8 -19 z";
	powerButtonArray[4] = "M 389 113 l 8 19 l 15 -1 l -12 -19 z";
	powerButtonArray[5] = "M 378 115 l 9 19 l 11 -3 l -11 -14 z";
	powerButtonArray[6] = "";
	powerButtonArray[7] = "";
	powerButtonArray[8] = "";
	powerButtonArray[9] = "";
	powerButtonArray[10] = "";
	powerButtonArray[11] = "";
	powerButtonArray[12] = "";
	powerButtonArray[13] = "";
	powerButtonArray[14] = "";
	powerButtonArray[15] = "";
	powerButtonArray[16] = "";
	powerButtonArray[17] = "";
	powerButtonArray[18] = "";	
	powerButtonArray[19] = "";
	powerButtonArray[20] = "M 244 103 l -8 21 l 14 -2 l 12 -20 z";
	powerButtonArray[21] = "M 278 104 l -3 17 l 14 0 l 6 -18 z";
	powerButtonArray[22] = "M 310 102 l -1 22 l 19 -2 l 4 -23 z";
	powerButtonArray[23] = "M 344 105 l 0 19 l 18 -2 l -1 -21 z";

	
	
	var i = 0;